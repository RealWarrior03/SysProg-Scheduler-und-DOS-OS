#ifndef COLORS_H
#define COLORS_H



void set_color(int index);

void reset_color();

#endif //COLORS_H/*
 * Created by Henry Krieger
 */
